# Vibe Workspace Template

Reusable Next.js + Material UI component workspace.

## Core rules
- Import reusable UI components from `@/components/ui`.
- Keep component props typed.
- Prefer Material UI icons.
- Use the provided hooks and theme utilities.
