'use client';
import { useMediaQuery as useMuiMediaQuery, Theme } from '@mui/material';
export const useMediaQuery=(query:string|((theme:Theme)=>string))=>useMuiMediaQuery(query);
export const useIsMobile=()=>useMediaQuery('(max-width: 768px)');
export const useIsTablet=()=>useMediaQuery('(max-width: 1024px)');
export const useIsDesktop=()=>useMediaQuery('(min-width: 1025px)');
export const useIsSmallScreen=()=>useMediaQuery('(max-width: 600px)');
