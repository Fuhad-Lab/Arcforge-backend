'use client';
import { useState,useCallback } from 'react';
export interface ModalState<T=any>{isOpen:boolean;data:T|null}
export const useModal=<T=any>(initialData:T|null=null)=>{const [state,setState]=useState<ModalState<T>>({isOpen:false,data:initialData});const open=useCallback((data?:T)=>setState({isOpen:true,data:data!==undefined?data:initialData}),[initialData]);const close=useCallback(()=>setState(p=>({...p,isOpen:false})),[]);const setData=useCallback((data:T|null)=>setState(p=>({...p,data})),[]);return {isOpen:state.isOpen,data:state.data,open,close,setData}};
