'use client';
import { useState,useEffect } from 'react';
export const useDebounce=<T>(value:T,delay=500):T=>{const [v,setV]=useState(value);useEffect(()=>{const t=setTimeout(()=>setV(value),delay);return()=>clearTimeout(t)},[value,delay]);return v};
