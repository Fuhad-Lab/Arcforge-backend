'use client';
import { ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { ReactNode } from 'react';
export default function SidebarItem({label,icon,active=false,onClick}:{label:string;icon?:ReactNode;active?:boolean;onClick?:()=>void}){return <ListItem disablePadding><ListItemButton selected={active} onClick={onClick}>{icon&&<ListItemIcon>{icon}</ListItemIcon>}<ListItemText primary={label}/></ListItemButton></ListItem>}
