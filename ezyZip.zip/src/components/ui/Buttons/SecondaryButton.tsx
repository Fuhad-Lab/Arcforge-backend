'use client';
import { Button, ButtonProps as MuiButtonProps, CircularProgress } from '@mui/material';
import { forwardRef, ReactNode } from 'react';

export interface SecondaryButtonProps extends Omit<MuiButtonProps, 'variant'> {
  children?: ReactNode;
  loading?: boolean;
  icon?: ReactNode;
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  disabled?: boolean;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

const SecondaryButton = forwardRef<HTMLButtonElement, SecondaryButtonProps>(
  ({ children, loading = false, icon, size = 'medium', fullWidth = false, disabled = false, onClick, ...props }, ref) => (
    <Button
      ref={ref}
      variant="outlined"
      color="primary"
      size={size}
      fullWidth={fullWidth}
      disabled={disabled || loading}
      onClick={onClick}
      startIcon={loading ? <CircularProgress size={20} color="inherit" /> : icon}
      sx={{
        textTransform: 'none', fontWeight: 600, borderRadius: 2, py: 1.5, px: 3, borderWidth: 2,
        '&:hover': { borderWidth: 2, backgroundColor: 'rgba(25, 118, 210, 0.04)' },
        '&:active': { backgroundColor: 'rgba(25, 118, 210, 0.08)' },
        transition: 'all 0.2s ease-in-out', ...props.sx,
      }}
      {...props}
    >
      {children}
    </Button>
  )
);
SecondaryButton.displayName = 'SecondaryButton';
export default SecondaryButton;
