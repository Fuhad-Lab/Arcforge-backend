'use client';
import { Button, ButtonProps as MuiButtonProps, CircularProgress } from '@mui/material';
import { forwardRef, ReactNode } from 'react';

export interface PrimaryButtonProps extends Omit<MuiButtonProps, 'variant'> {
  children?: ReactNode;
  loading?: boolean;
  loadingText?: string;
  icon?: ReactNode;
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  disabled?: boolean;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

const PrimaryButton = forwardRef<HTMLButtonElement, PrimaryButtonProps>(
  ({ children, loading = false, loadingText, icon, size = 'medium', fullWidth = false, disabled = false, onClick, ...props }, ref) => (
    <Button
      ref={ref}
      variant="contained"
      color="primary"
      size={size}
      fullWidth={fullWidth}
      disabled={disabled || loading}
      onClick={onClick}
      startIcon={loading ? <CircularProgress size={20} color="inherit" /> : icon}
      sx={{
        textTransform: 'none', fontWeight: 600, borderRadius: 2, py: 1.5, px: 3, boxShadow: 2,
        '&:hover': { boxShadow: 4, transform: 'translateY(-1px)' },
        '&:active': { transform: 'translateY(0px)' },
        transition: 'all 0.2s ease-in-out', ...props.sx,
      }}
      {...props}
    >
      {loading && loadingText ? loadingText : children}
    </Button>
  )
);
PrimaryButton.displayName = 'PrimaryButton';
export default PrimaryButton;
