'use client';
import { ButtonGroup as MuiButtonGroup, ButtonGroupProps as MuiButtonGroupProps, Button } from '@mui/material';
import { ReactNode, forwardRef } from 'react';

export interface ButtonGroupProps extends MuiButtonGroupProps {
  children?: ReactNode;
  variant?: 'text' | 'outlined' | 'contained';
  size?: 'small' | 'medium' | 'large';
  orientation?: 'horizontal' | 'vertical';
  color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
  exclusive?: boolean;
  selectedValue?: string | number;
  onChange?: (value: string | number) => void;
}
interface ButtonItem { value: string | number; label: string; icon?: ReactNode; disabled?: boolean; }
export interface ButtonGroupWithItemsProps extends ButtonGroupProps { items?: ButtonItem[]; }

const ButtonGroup = forwardRef<HTMLDivElement, ButtonGroupWithItemsProps>(
  ({ children, variant = 'outlined', size = 'medium', orientation = 'horizontal', color = 'primary', exclusive = false, selectedValue, onChange, items, ...props }, ref) => {
    const content = items?.length ? items.map(item => (
      <Button
        key={item.value} value={item.value} disabled={item.disabled} startIcon={item.icon}
        onClick={() => onChange?.(item.value)}
        sx={{
          ...(exclusive && selectedValue === item.value && {
            backgroundColor: 'rgba(25, 118, 210, 0.1)',
            '&:hover': { backgroundColor: 'rgba(25, 118, 210, 0.15)' },
          }),
        }}
      >{item.label}</Button>
    )) : children;
    return (
      <MuiButtonGroup
        ref={ref} variant={variant} size={size} orientation={orientation} color={color}
        sx={{ '& .MuiButton-root': { textTransform: 'none', fontWeight: 500 }, ...props.sx }}
        {...props}
      >{content}</MuiButtonGroup>
    );
  }
);
ButtonGroup.displayName = 'ButtonGroup';
export default ButtonGroup;
