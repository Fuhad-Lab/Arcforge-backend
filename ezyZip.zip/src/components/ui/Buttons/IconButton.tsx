'use client';
import { IconButton as MuiIconButton, IconButtonProps as MuiIconButtonProps, Tooltip, CircularProgress } from '@mui/material';
import { forwardRef, ReactNode } from 'react';

export interface IconButtonProps extends MuiIconButtonProps {
  children?: ReactNode;
  tooltip?: string;
  size?: 'small' | 'medium' | 'large';
  color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning' | 'default';
  loading?: boolean;
  ariaLabel?: string;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ children, tooltip, size = 'medium', color = 'default', loading = false, ariaLabel, onClick, ...props }, ref) => {
    const button = (
      <MuiIconButton
        ref={ref} size={size} color={color} disabled={loading || props.disabled}
        aria-label={ariaLabel} onClick={onClick}
        sx={{
          '&:hover': { backgroundColor: 'rgba(25, 118, 210, 0.08)' },
          '&:focus': { outline: '2px solid #1976d2', outlineOffset: '2px' }, ...props.sx,
        }}
        {...props}
      >
        {loading ? <CircularProgress size={size === 'small' ? 16 : 24} /> : children}
      </MuiIconButton>
    );
    return tooltip ? <Tooltip title={tooltip} arrow>{button}</Tooltip> : button;
  }
);
IconButton.displayName = 'IconButton';
export default IconButton;
