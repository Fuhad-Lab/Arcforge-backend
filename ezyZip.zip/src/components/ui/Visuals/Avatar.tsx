'use client';
import { Avatar as MuiAvatar, AvatarProps as MuiAvatarProps, Badge, Box } from '@mui/material';
import { forwardRef, ReactNode } from 'react';
export interface AvatarProps extends MuiAvatarProps { src?:string; alt?:string; size?:'small'|'medium'|'large'|'xlarge'; name?:string; showStatus?:boolean; status?:'online'|'offline'|'away'|'busy'; badgeContent?:ReactNode; onClick?:(event:React.MouseEvent<HTMLDivElement>)=>void; }
const getSize=(s:string)=>s==='small'?32:s==='large'?56:s==='xlarge'?80:40;
const statusColor=(s:string)=>s==='online'?'#4caf50':s==='away'?'#ff9800':s==='busy'?'#f44336':'#9e9e9e';
const initials=(n:string)=>n.split(' ').map(x=>x[0]).join('').toUpperCase().slice(0,2);
const Avatar=forwardRef<HTMLDivElement,AvatarProps>(({src,alt,size='medium',name,showStatus=false,status='offline',badgeContent,onClick,...props},ref)=>{
  const n=getSize(size); const avatar=<MuiAvatar ref={ref} src={src} alt={alt||name} onClick={onClick} sx={{width:n,height:n,cursor:onClick?'pointer':'default',fontSize:n*.4,fontWeight:600,bgcolor:src?undefined:'primary.main',...props.sx}} {...props}>{!src&&name&&initials(name)}</MuiAvatar>;
  if(showStatus)return <Box sx={{position:'relative',display:'inline-block'}}>{avatar}<Box sx={{position:'absolute',bottom:0,right:0,width:n*.3,height:n*.3,borderRadius:'50%',bgcolor:statusColor(status),border:'2px solid white'}}/></Box>;
  if(badgeContent)return <Badge overlap="circular" anchorOrigin={{vertical:'bottom',horizontal:'right'}} badgeContent={badgeContent}>{avatar}</Badge>;
  return avatar;
});
Avatar.displayName='Avatar';
export default Avatar;
