'use client';
import { ReactNode } from 'react';
export default function Icon({children}:{children:ReactNode}){return <span>{children}</span>}
