'use client';
import { Spinner } from './Spinner';
export default function LoadingOverlay({loading=true}:{loading?:boolean}){return loading?<Spinner overlay/>:null}
