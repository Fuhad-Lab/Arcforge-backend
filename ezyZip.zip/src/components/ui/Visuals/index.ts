export { default as Spinner } from './Spinner';
export { default as Avatar } from './Avatar';
export type { SpinnerProps } from './Spinner';
export type { AvatarProps } from './Avatar';
