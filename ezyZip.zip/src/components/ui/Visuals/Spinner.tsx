'use client';
import { CircularProgress, Box, Typography, Backdrop } from '@mui/material';
import { ReactNode } from 'react';
export interface SpinnerProps { size?: number|'small'|'medium'|'large'|string; thickness?: number; color?: 'primary'|'secondary'|'inherit'|'error'|'info'|'success'|'warning'; label?: string; overlay?: boolean; overlayOpacity?: number; center?: boolean; children?: ReactNode; }
const getSize=(size:string|number):number=>typeof size==='number'?size:size==='small'?24:size==='large'?60:40;
export const Spinner=({size='medium',thickness=4,color='primary',label,overlay=false,overlayOpacity=.5,center=false,children}:SpinnerProps)=>{
  const content=<Box sx={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:2,...(center&&{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)'})}}>
    <CircularProgress size={getSize(size)} thickness={thickness} color={color}/>{label&&<Typography variant="body2" color="text.secondary">{label}</Typography>}{children}
  </Box>;
  return overlay?<Backdrop sx={{color:'#fff',zIndex:t=>t.zIndex.drawer+1,backgroundColor:`rgba(255,255,255,${overlayOpacity})`}} open>{content}</Backdrop>:content;
};
export default Spinner;
