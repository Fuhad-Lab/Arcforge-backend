'use client';
import { InputBase, InputAdornment, IconButton, Paper, styled } from '@mui/material';
import { Search, Clear } from '@mui/icons-material';
import { useState, forwardRef } from 'react';
export interface SearchBarProps { placeholder?:string;value?:string;defaultValue?:string;onChange?:(value:string)=>void;onSearch?:(value:string)=>void;onClear?:()=>void;autoFocus?:boolean;disabled?:boolean;fullWidth?:boolean;size?:'small'|'medium'|'large';showClearButton?:boolean;variant?:'outlined'|'filled'|'standard'; }
const StyledPaper=styled(Paper)(({theme})=>({padding:'2px 4px',display:'flex',alignItems:'center',width:'auto',borderRadius:theme.shape.borderRadius*2,transition:'all .3s ease','&:hover':{boxShadow:theme.shadows[4]},'&:focus-within':{boxShadow:theme.shadows[8]}}));
const SearchBar=forwardRef<HTMLDivElement,SearchBarProps>(({placeholder='Search...',value,defaultValue,onChange,onSearch,onClear,autoFocus=false,disabled=false,fullWidth=true,size='medium',showClearButton=true,variant='outlined'},ref)=>{
 const [v,setV]=useState(defaultValue||''); const display=value!==undefined?value:v; const change=(e:React.ChangeEvent<HTMLInputElement>)=>{setV(e.target.value);onChange?.(e.target.value)}; const clear=()=>{setV('');onChange?.('');onClear?.()}; return <StyledPaper ref={ref} elevation={variant==='outlined'?1:0} sx={{height:size==='small'?40:size==='large'?56:48,width:fullWidth?'100%':'auto',...(variant==='filled'&&{backgroundColor:'action.hover'}),...(variant==='standard'&&{borderBottom:'2px solid',borderColor:'divider',borderRadius:0,boxShadow:'none'})}}><InputAdornment position="start" sx={{ml:1}}><Search color="action"/></InputAdornment><InputBase sx={{ml:1,flex:1,fontSize:size==='small'?'.875rem':'1rem'}} placeholder={placeholder} value={display} onChange={change} onKeyDown={e=>e.key==='Enter'&&onSearch?.(display)} autoFocus={autoFocus} disabled={disabled} inputProps={{'aria-label':'search'}}/>{showClearButton&&display&&<IconButton sx={{p:'10px'}} onClick={clear} aria-label="clear search"><Clear/></IconButton>}</StyledPaper>;
});
SearchBar.displayName='SearchBar';
export default SearchBar;
