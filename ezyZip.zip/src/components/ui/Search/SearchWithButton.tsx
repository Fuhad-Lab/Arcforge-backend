'use client';
import { TextField, InputAdornment, Button, Box, CircularProgress } from '@mui/material';
import { Search } from '@mui/icons-material';
import { useState } from 'react';
export interface SearchWithButtonProps {placeholder?:string;value?:string;defaultValue?:string;onChange?:(value:string)=>void;onSearch?:(value:string)=>void;onClear?:()=>void;buttonText?:string;loading?:boolean;disabled?:boolean;fullWidth?:boolean;size?:'small'|'medium'|'large';variant?:'outlined'|'filled';}
const SearchWithButton=({placeholder='Search...',value,defaultValue,onChange,onSearch,buttonText='Search',loading=false,disabled=false,fullWidth=true,size='medium',variant='outlined'}:SearchWithButtonProps)=>{
 const [v,setV]=useState(defaultValue||'');const display=value!==undefined?value:v;const change=(e:React.ChangeEvent<HTMLInputElement>)=>{setV(e.target.value);onChange?.(e.target.value)};const search=()=>!loading&&!disabled&&onSearch?.(display);
 return <Box sx={{display:'flex',gap:1,alignItems:'center',width:fullWidth?'100%':'auto'}}><TextField placeholder={placeholder} value={display} onChange={change} onKeyDown={e=>e.key==='Enter'&&search()} disabled={disabled||loading} size={size==='large'?'medium':size} fullWidth={fullWidth} variant={variant} InputProps={{startAdornment:<InputAdornment position="start"><Search/></InputAdornment>}} sx={{'& .MuiOutlinedInput-root':{borderRadius:2}}}/><Button variant="contained" onClick={search} disabled={disabled||loading} size={size==='large'?'large':'medium'} sx={{minWidth:100,height:size==='large'?56:size==='small'?40:48,textTransform:'none',fontWeight:600}}>{loading?<CircularProgress size={20} color="inherit"/>:buttonText}</Button></Box>;
};
export default SearchWithButton;
