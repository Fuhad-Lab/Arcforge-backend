export const textStyles={body:{lineHeight:1.6},caption:{fontSize:'.75rem'}} as const;
