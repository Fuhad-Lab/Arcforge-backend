'use client';
import { Typography as MuiTypography, TypographyProps as MuiTypographyProps } from '@mui/material';
import { forwardRef, ReactNode } from 'react';
export interface ParagraphProps extends Omit<MuiTypographyProps,'variant'> {
  children?: ReactNode; size?: 'small'|'medium'|'large'; align?: 'left'|'center'|'right'|'justify';
  color?: 'primary'|'secondary'|'text.primary'|'text.secondary'|'text.disabled'|'error'|'success'|'warning'|'info';
  gutterBottom?: boolean; noWrap?: boolean; bold?: boolean; italic?: boolean; lineHeight?: number|string; maxWidth?: string|number;
}
const Paragraph=forwardRef<HTMLElement,ParagraphProps>(({children,size='medium',align,color,gutterBottom=false,noWrap=false,bold=false,italic=false,lineHeight=1.6,maxWidth,...props},ref)=>{
  const variant=size==='small'?'body2':size==='large'?'h6':'body1';
  return <MuiTypography ref={ref} variant={variant} align={align} color={color} gutterBottom={gutterBottom} noWrap={noWrap}
    sx={{fontWeight:bold?600:400,fontStyle:italic?'italic':'normal',lineHeight,maxWidth,marginBottom:gutterBottom?2:undefined,...props.sx}} {...props}>{children}</MuiTypography>;
});
Paragraph.displayName='Paragraph';
export default Paragraph;
