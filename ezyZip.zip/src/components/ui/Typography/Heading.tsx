'use client';
import { Typography as MuiTypography, TypographyProps as MuiTypographyProps } from '@mui/material';
import { forwardRef, ReactNode } from 'react';

export interface HeadingProps extends Omit<MuiTypographyProps, 'variant'> {
  children?: ReactNode; level?: 1|2|3|4|5|6; align?: 'left'|'center'|'right'|'justify';
  color?: 'primary'|'secondary'|'text.primary'|'text.secondary'|'text.disabled'|'error'|'success'|'warning'|'info';
  gutterBottom?: boolean; noWrap?: boolean; underline?: 'none'|'hover'|'always'; italic?: boolean;
  bold?: boolean; transform?: 'none'|'capitalize'|'uppercase'|'lowercase'; letterSpacing?: string|number;
}
const Heading = forwardRef<HTMLElement, HeadingProps>(
  ({ children, level=1, align, color, gutterBottom=false, noWrap=false, underline='none', italic=false, bold, transform, letterSpacing, ...props }, ref) => (
    <MuiTypography ref={ref} variant={`h${level}` as any} align={align} color={color} gutterBottom={gutterBottom} noWrap={noWrap}
      sx={{ fontWeight:bold!==undefined?(bold?700:400):undefined, fontStyle:italic?'italic':undefined, textTransform:transform, letterSpacing, lineHeight:level<=2?1.2:1.4, marginBottom:gutterBottom?2:undefined, ...props.sx }}
      {...props}>{children}</MuiTypography>
  )
);
Heading.displayName='Heading';
export const H1=(p:Omit<HeadingProps,'level'>)=><Heading level={1}{...p}/>;
export const H2=(p:Omit<HeadingProps,'level'>)=><Heading level={2}{...p}/>;
export const H3=(p:Omit<HeadingProps,'level'>)=><Heading level={3}{...p}/>;
export const H4=(p:Omit<HeadingProps,'level'>)=><Heading level={4}{...p}/>;
export const H5=(p:Omit<HeadingProps,'level'>)=><Heading level={5}{...p}/>;
export const H6=(p:Omit<HeadingProps,'level'>)=><Heading level={6}{...p}/>;
export default Heading;
