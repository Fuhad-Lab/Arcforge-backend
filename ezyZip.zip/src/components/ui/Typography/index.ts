export { default as Heading, H1, H2, H3, H4, H5, H6 } from './Heading';
export { default as Paragraph } from './Paragraph';
export type { HeadingProps } from './Heading';
export type { ParagraphProps } from './Paragraph';
