'use client';
import { Switch as MuiSwitch, SwitchProps as MuiSwitchProps, FormControlLabel, FormHelperText, Typography } from '@mui/material';
import { forwardRef } from 'react';

export interface ToggleSwitchProps extends MuiSwitchProps {
  label?: string; labelPlacement?: 'start' | 'end' | 'top' | 'bottom'; helperText?: string; error?: boolean;
  size?: 'small' | 'medium'; color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
  checked?: boolean; onChange?: (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void;
}
const ToggleSwitch = forwardRef<HTMLButtonElement, ToggleSwitchProps>(
  ({ label, labelPlacement='start', helperText, error=false, size='medium', color='primary', checked, onChange, ...props }, ref) => {
    const switchComponent = <MuiSwitch ref={ref} size={size} color={color} checked={checked} onChange={onChange}
      sx={{ '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { opacity:1 }, ...props.sx }} {...props} />;
    return label ? <><FormControlLabel control={switchComponent} label={<Typography variant="body2">{label}</Typography>} labelPlacement={labelPlacement}/>{helperText && <FormHelperText error={error}>{helperText}</FormHelperText>}</> : switchComponent;
  }
);
ToggleSwitch.displayName = 'ToggleSwitch';
export default ToggleSwitch;
