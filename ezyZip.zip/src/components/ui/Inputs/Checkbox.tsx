'use client';
import { Checkbox as MuiCheckbox, CheckboxProps as MuiCheckboxProps, FormControlLabel, FormHelperText, Typography } from '@mui/material';
import { forwardRef } from 'react';

export interface CheckboxProps extends MuiCheckboxProps {
  label?: string; labelPlacement?: 'start' | 'end' | 'top' | 'bottom'; helperText?: string;
  error?: boolean; required?: boolean; size?: 'small' | 'medium';
  color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
}
const Checkbox = forwardRef<HTMLButtonElement, CheckboxProps>(
  ({ label, labelPlacement='end', helperText, error=false, required=false, size='medium', color='primary', ...props }, ref) => {
    const checkbox = <MuiCheckbox ref={ref} size={size} color={color} required={required}
      sx={{ '&.Mui-checked': { transform: 'scale(1.1)' }, ...props.sx }} {...props} />;
    return label ? (
      <>
        <FormControlLabel control={checkbox} label={<Typography variant="body2" component="span">{label}{required && <Typography component="span" color="error" sx={{ml:.5}}>*</Typography>}</Typography>} labelPlacement={labelPlacement} />
        {helperText && <FormHelperText error={error}>{helperText}</FormHelperText>}
      </>
    ) : checkbox;
  }
);
Checkbox.displayName = 'Checkbox';
export default Checkbox;
