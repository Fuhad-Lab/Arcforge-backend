'use client';
import { TextField, InputAdornment, IconButton, FormHelperText } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { forwardRef, useState } from 'react';

export interface PasswordFieldProps {
  label?: string; placeholder?: string; required?: boolean; disabled?: boolean; error?: boolean;
  helperText?: string; size?: 'small' | 'medium'; fullWidth?: boolean; name?: string; value?: string;
  defaultValue?: string; onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void; showPasswordToggle?: boolean;
}
const PasswordField = forwardRef<HTMLDivElement, PasswordFieldProps>(
  ({ label='Password', placeholder='Enter your password', required=false, disabled=false, error=false,
    helperText, size='medium', fullWidth=true, name, value, defaultValue, onChange, onBlur,
    showPasswordToggle=true }, ref) => {
    const [showPassword, setShowPassword] = useState(false);
    return (
      <>
        <TextField
          ref={ref} label={label} placeholder={placeholder} type={showPassword ? 'text' : 'password'}
          required={required} disabled={disabled} error={error} name={name} value={value}
          defaultValue={defaultValue} onChange={onChange} onBlur={onBlur} size={size} fullWidth={fullWidth}
          margin="normal"
          InputProps={{
            endAdornment: showPasswordToggle && (
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={() => setShowPassword(v => !v)}
                  onMouseDown={e => e.preventDefault()} edge="end"
                >{showPassword ? <VisibilityOff /> : <Visibility />}</IconButton>
              </InputAdornment>
            ),
          }}
          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2, '& fieldset': { borderWidth: 2 },
            '&:hover fieldset': { borderWidth: 2 }, '&.Mui-focused fieldset': { borderWidth: 2 } } }}
        />
        {helperText && <FormHelperText error={error}>{helperText}</FormHelperText>}
      </>
    );
  }
);
PasswordField.displayName = 'PasswordField';
export default PasswordField;
