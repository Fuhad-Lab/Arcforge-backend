'use client';
import { TextField as MuiTextField, TextFieldProps as MuiTextFieldProps, InputAdornment } from '@mui/material';
import { forwardRef, ReactNode } from 'react';

export interface TextFieldProps extends Omit<MuiTextFieldProps, 'variant'> {
  label?: string; placeholder?: string; required?: boolean; disabled?: boolean; error?: boolean;
  helperText?: string; icon?: ReactNode; endIcon?: ReactNode; size?: 'small' | 'medium';
  fullWidth?: boolean; variant?: 'outlined' | 'filled' | 'standard'; type?: string; name?: string;
  value?: string; defaultValue?: string;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
  onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;
}
const TextField = forwardRef<HTMLDivElement, TextFieldProps>(
  ({ label, placeholder, required=false, disabled=false, error=false, helperText, icon, endIcon,
    size='medium', fullWidth=true, variant='outlined', type='text', name, value, defaultValue,
    onChange, onBlur, onFocus, ...props }, ref) => (
    <MuiTextField
      ref={ref} label={label} placeholder={placeholder} required={required} disabled={disabled}
      error={error} type={type} name={name} value={value} defaultValue={defaultValue}
      onChange={onChange} onBlur={onBlur} onFocus={onFocus} variant={variant} size={size}
      fullWidth={fullWidth} margin="normal" helperText={helperText}
      InputProps={{
        startAdornment: icon && <InputAdornment position="start">{icon}</InputAdornment>,
        endAdornment: endIcon && <InputAdornment position="end">{endIcon}</InputAdornment>,
      }}
      sx={{
        '& .MuiOutlinedInput-root': {
          borderRadius: 2, '& fieldset': { borderWidth: 2 },
          '&:hover fieldset': { borderWidth: 2 }, '&.Mui-focused fieldset': { borderWidth: 2 },
        }, ...props.sx,
      }}
      {...props}
    />
  )
);
TextField.displayName = 'TextField';
export default TextField;
