'use client';
import { RadioGroup as MuiRadioGroup, RadioGroupProps as MuiRadioGroupProps, FormControlLabel, Radio, FormHelperText, FormControl, FormLabel, Typography } from '@mui/material';
import { forwardRef } from 'react';

export interface RadioOption { value: string | number; label: string; disabled?: boolean; description?: string; }
export interface RadioGroupProps extends Omit<MuiRadioGroupProps, 'onChange'> {
  label?: string; options: RadioOption[]; helperText?: string; error?: boolean; required?: boolean;
  size?: 'small' | 'medium'; color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
  onChange?: (event: React.ChangeEvent<HTMLInputElement>, value: string) => void;
}
const RadioGroup = forwardRef<HTMLDivElement, RadioGroupProps>(
  ({ label, options, helperText, error=false, required=false, size='medium', color='primary', onChange, ...props }, ref) => (
    <FormControl required={required} error={error} component="fieldset">
      {label && <FormLabel component="legend"><Typography variant="body2" fontWeight={500}>{label}</Typography></FormLabel>}
      <MuiRadioGroup ref={ref} onChange={onChange} sx={{ '& .MuiFormControlLabel-root': { mb:.5 } }} {...props}>
        {options.map(option => (
          <FormControlLabel key={option.value} value={option.value} disabled={option.disabled}
            control={<Radio size={size} color={color} sx={{ '&.Mui-checked': { transform:'scale(1.1)' } }} />}
            label={<div><Typography variant="body2">{option.label}</Typography>{option.description && <Typography variant="caption" color="text.secondary">{option.description}</Typography>}</div>}
          />
        ))}
      </MuiRadioGroup>
      {helperText && <FormHelperText>{helperText}</FormHelperText>}
    </FormControl>
  )
);
RadioGroup.displayName = 'RadioGroup';
export default RadioGroup;
