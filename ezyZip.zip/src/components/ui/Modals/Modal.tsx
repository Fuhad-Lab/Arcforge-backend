'use client';
import { Modal as MuiModal, Box, Typography, IconButton, Fade, Backdrop } from '@mui/material';
import { Close } from '@mui/icons-material';
import { ReactNode } from 'react';
export interface ModalProps {open:boolean;onClose:()=>void;title?:string;children?:ReactNode;actions?:ReactNode;maxWidth?:number|string;showCloseButton?:boolean;disableBackdropClick?:boolean;disableEscapeKeyDown?:boolean;centered?:boolean;}
const Modal=({open,onClose,title,children,actions,maxWidth=500,showCloseButton=true,disableBackdropClick=false,disableEscapeKeyDown=false,centered=true}:ModalProps)=>{
 const close=(_:unknown,reason:'backdropClick'|'escapeKeyDown')=>{if((disableBackdropClick&&reason==='backdropClick')||(disableEscapeKeyDown&&reason==='escapeKeyDown'))return;onClose()};
 return <MuiModal open={open} onClose={close} closeAfterTransition slots={{backdrop:Backdrop}} slotProps={{backdrop:{timeout:300,sx:{backgroundColor:'rgba(0,0,0,.5)',backdropFilter:'blur(4px)'}}}}><Fade in={open}><Box sx={{position:'absolute',top:centered?'50%':'20%',left:'50%',transform:centered?'translate(-50%,-50%)':'translate(-50%,0)',width:'min(90vw, '+maxWidth+')',bgcolor:'background.paper',borderRadius:3,boxShadow:24,p:4,outline:'none',maxHeight:'90vh',overflowY:'auto'}}>{showCloseButton&&<IconButton aria-label="close" onClick={onClose} sx={{position:'absolute',right:8,top:8}}><Close/></IconButton>}{title&&<Typography variant="h6" gutterBottom fontWeight={600}>{title}</Typography>}{children}{actions&&<Box sx={{mt:3,display:'flex',justifyContent:'flex-end',gap:1}}>{actions}</Box>}</Box></Fade></MuiModal>;
};
export default Modal;
