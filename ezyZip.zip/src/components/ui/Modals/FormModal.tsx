'use client';
import Modal, { ModalProps } from './Modal';
export default function FormModal(props: ModalProps){return <Modal {...props}/>;}
