'use client';
import { Box, Typography, Button, CircularProgress } from '@mui/material';
import { Warning, Delete } from '@mui/icons-material';
import Modal from './Modal';
export interface ConfirmModalProps {open:boolean;onClose:()=>void;onConfirm:()=>void;title?:string;message?:string;confirmText?:string;cancelText?:string;type?:'danger'|'warning'|'info';loading?:boolean;}
const ConfirmModal=({open,onClose,onConfirm,title='Confirm Action',message='Are you sure you want to proceed?',confirmText='Confirm',cancelText='Cancel',type='warning',loading=false}:ConfirmModalProps)=>{
 const cfg=type==='danger'?{icon:<Delete color="error"/>,color:'error' as const,bg:'error.light'}:type==='warning'?{icon:<Warning color="warning"/>,color:'warning' as const,bg:'warning.light'}:{icon:<Warning color="info"/>,color:'primary' as const,bg:'info.light'};
 return <Modal open={open} onClose={onClose} title={title} maxWidth={400}><Box sx={{display:'flex',alignItems:'center',gap:2,mb:2}}><Box sx={{width:48,height:48,borderRadius:'50%',bgcolor:cfg.bg,display:'flex',alignItems:'center',justifyContent:'center'}}>{cfg.icon}</Box><Typography color="text.secondary">{message}</Typography></Box><Box sx={{display:'flex',justifyContent:'flex-end',gap:1}}><Button variant="outlined" onClick={onClose} disabled={loading} sx={{textTransform:'none'}}>{cancelText}</Button><Button variant="contained" color={cfg.color} onClick={onConfirm} disabled={loading} sx={{textTransform:'none'}}>{loading?<CircularProgress size={20} color="inherit"/>:confirmText}</Button></Box></Modal>;
};
export default ConfirmModal;
