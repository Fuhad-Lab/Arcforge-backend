'use client';
import { Card, CardContent, Avatar, Typography, Box } from '@mui/material';
export default function ProfileCard({name='User',email,avatar}:{name?:string;email?:string;avatar?:string}){return <Card sx={{maxWidth:345}}><CardContent><Box sx={{display:'flex',alignItems:'center',gap:2}}><Avatar src={avatar} sx={{width:56,height:56}}>{name[0]}</Avatar><Box><Typography variant="h6">{name}</Typography>{email&&<Typography variant="body2" color="text.secondary">{email}</Typography>}</Box></Box></CardContent></Card>}
