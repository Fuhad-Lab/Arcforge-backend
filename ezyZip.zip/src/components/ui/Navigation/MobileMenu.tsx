'use client';
import { Drawer } from '@mui/material';
import { ReactNode } from 'react';
export default function MobileMenu({open,onClose,children}:{open:boolean;onClose:()=>void;children:ReactNode}){return <Drawer anchor="left" open={open} onClose={onClose}>{children}</Drawer>}
