'use client';
import Link from 'next/link';
import { ReactNode } from 'react';

export interface NavLinkProps {
  href: string;
  children: ReactNode;
  icon?: ReactNode;
  active?: boolean;
  onClick?: () => void;
}

export default function NavLink({ href, children, icon, active=false, onClick }: NavLinkProps) {
  return <Link href={href} onClick={onClick} style={{ textDecoration:'none', color:'inherit', display:'inline-flex', alignItems:'center', gap:8, fontWeight:active?600:400 }}>{icon}{children}</Link>;
}
