'use client';
import { MenuItem as MuiMenuItem, MenuItemProps } from '@mui/material';
export default function MenuItem(props:MenuItemProps){return <MuiMenuItem {...props}/>}
