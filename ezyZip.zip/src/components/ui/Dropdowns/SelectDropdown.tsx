'use client';
import { Select, MenuItem } from '@mui/material';
export default function SelectDropdown({options=[],value,onChange}:{options:{label:string;value:string|number}[];value?:any;onChange?:(e:any)=>void}){return <Select value={value??''} onChange={onChange} fullWidth>{options.map(o=><MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}</Select>}
