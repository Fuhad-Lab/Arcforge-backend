'use client';
import { Tooltip as MuiTooltip, TooltipProps as MuiTooltipProps, Box } from '@mui/material';
import { ReactNode, forwardRef } from 'react';
export interface TooltipProps extends Omit<MuiTooltipProps,'title'>{title:ReactNode;children:ReactNode;placement?:any;arrow?:boolean;interactive?:boolean;enterDelay?:number;leaveDelay?:number;variant?:'dark'|'light';}
const Tooltip=forwardRef<HTMLDivElement,TooltipProps>(({title,children,placement='top',arrow=true,interactive=false,enterDelay=100,leaveDelay=0,variant='dark',...props},ref)=><MuiTooltip ref={ref} title={title} placement={placement} arrow={arrow} interactive={interactive} enterDelay={enterDelay} leaveDelay={leaveDelay} componentsProps={{tooltip:{sx:{backgroundColor:variant==='dark'?'rgba(0,0,0,.87)':'#fff',color:variant==='dark'?'#fff':'rgba(0,0,0,.87)',boxShadow:variant==='light'?'0 4px 6px -1px rgba(0,0,0,.1)':'none',fontSize:'.875rem',padding:'8px 12px',borderRadius:1,maxWidth:300}}}} {...props}><Box sx={{display:'inline-block'}}>{children}</Box></MuiTooltip>);
Tooltip.displayName='Tooltip';export default Tooltip;
