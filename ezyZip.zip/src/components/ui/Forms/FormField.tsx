'use client';
import { Box, Typography, FormHelperText } from '@mui/material';
import { ReactNode, forwardRef } from 'react';
export interface FormFieldProps {label?:string;required?:boolean;error?:boolean;helperText?:string;children:ReactNode;description?:string;fullWidth?:boolean;}
const FormField=forwardRef<HTMLDivElement,FormFieldProps>(({label,required=false,error=false,helperText,children,description,fullWidth=true},ref)=><Box ref={ref} sx={{display:'flex',flexDirection:'column',gap:1,width:fullWidth?'100%':'auto'}}>{label&&<Typography variant="body2" component="label" sx={{fontWeight:500}}>{label}{required&&<Typography component="span" color="error" fontWeight="bold">*</Typography>}</Typography>}{description&&<Typography variant="caption" color="text.secondary">{description}</Typography>}{children}{error&&helperText&&<FormHelperText error sx={{mt:0}}>{helperText}</FormHelperText>}</Box>);
FormField.displayName='FormField';export default FormField;
