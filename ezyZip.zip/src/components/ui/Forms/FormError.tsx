'use client';
import { Box, Typography, Alert, Collapse, IconButton } from '@mui/material';
import { Error, Close } from '@mui/icons-material';
export interface FormErrorProps {message?:string;errors?:Record<string,string>;show?:boolean;onClose?:()=>void;variant?:'alert'|'inline'|'list';}
const FormError=({message,errors,show=true,onClose,variant='alert'}:FormErrorProps)=>{if(!show)return null;const has=!!(message?.length||(errors&&Object.keys(errors).length));if(!has)return null;
 if(variant==='alert')return <Collapse in={show}><Alert severity="error" action={onClose&&<IconButton aria-label="close" color="inherit" size="small" onClick={onClose}><Close fontSize="inherit"/></IconButton>} sx={{borderRadius:2,mb:2}}>{message}{errors&&<Box component="ul" sx={{pl:2,mt:1}}>{Object.entries(errors).map(([f,e])=><Typography key={f} component="li" variant="body2">{e}</Typography>)}</Box>}</Alert></Collapse>;
 if(variant==='list')return <Box sx={{mt:1}}>{message&&<Typography color="error" variant="body2" sx={{mb:1}}>{message}</Typography>}{errors&&Object.entries(errors).map(([f,e])=><Typography key={f} color="error" variant="caption" display="block">• {e}</Typography>)}</Box>;
 return <Box sx={{display:'flex',alignItems:'center',gap:1,mt:1}}><Error color="error" fontSize="small"/><Typography color="error" variant="body2">{message||Object.values(errors||{})[0]}</Typography></Box>;
};
export default FormError;
