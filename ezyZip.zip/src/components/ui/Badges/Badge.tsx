'use client';
import { Chip, ChipProps as MuiChipProps } from '@mui/material';
import { ReactNode } from 'react';
export interface BadgeProps extends Omit<MuiChipProps,'variant'>{children?:ReactNode;variant?:'filled'|'outlined';color?:'primary'|'secondary'|'error'|'info'|'success'|'warning'|'default';size?:'small'|'medium';icon?:ReactNode;deleteIcon?:ReactNode;onDelete?:()=>void;onClick?:(event:React.MouseEvent<HTMLDivElement>)=>void;}
const Badge=({children,variant='filled',color='default',size='medium',icon,deleteIcon,onDelete,onClick,...props}:BadgeProps)=><Chip label={children} variant={variant} color={color} size={size} icon={icon} deleteIcon={deleteIcon} onDelete={onDelete} onClick={onClick} sx={{fontWeight:500,fontSize:size==='small'?'.75rem':'.875rem',height:size==='small'?24:32,'& .MuiChip-label':{padding:size==='small'?'0 8px':'0 12px'},...props.sx}} {...props}/>;
export default Badge;
