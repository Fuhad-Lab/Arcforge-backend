'use client';
import { Chip, ChipProps } from '@mui/material';
export interface StatusChipProps extends Omit<ChipProps,'variant'|'color'>{status:'active'|'pending'|'inactive'|'completed'|'failed'|'processing'|'cancelled';label?:string;size?:'small'|'medium';showDot?:boolean;}
const config:any={active:['success','Active','#4caf50'],pending:['warning','Pending','#ff9800'],inactive:['default','Inactive','#9e9e9e'],completed:['info','Completed','#2196f3'],failed:['error','Failed','#f44336'],processing:['primary','Processing','#1976d2'],cancelled:['secondary','Cancelled','#dc004e']};
const StatusChip=({status,label,size='medium',showDot=true,...props}:StatusChipProps)=>{const [color,text,dot]=config[status]||config.inactive;return <Chip label={<span style={{display:'flex',alignItems:'center',gap:6}}>{showDot&&<span style={{width:8,height:8,borderRadius:'50%',backgroundColor:dot,display:'inline-block'}}/>}{label||text}</span>} variant="outlined" color={color} size={size} sx={{fontWeight:500,borderColor:`${dot}40`,backgroundColor:`${dot}10`,color:dot,'& .MuiChip-label':{padding:size==='small'?'0 8px':'0 12px'},...props.sx}} {...props}/>};
export default StatusChip;
