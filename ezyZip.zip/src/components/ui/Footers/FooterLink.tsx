'use client';
import Link from 'next/link';
export default function FooterLink({href='#',children}:{href?:string;children:React.ReactNode}){return <Link href={href} style={{textDecoration:'none'}}>{children}</Link>}
