export { default as Footer } from './Footer';
export { default as FooterLink } from './FooterLink';
export type { FooterProps, FooterSection, FooterLink as FooterLinkType } from './Footer';
