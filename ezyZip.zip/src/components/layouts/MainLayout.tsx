'use client';
import { ReactNode } from 'react';
import { Box } from '@mui/material';
export default function MainLayout({children}:{children:ReactNode}){return <Box component="main" sx={{minHeight:'100vh'}}>{children}</Box>}
