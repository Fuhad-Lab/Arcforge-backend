'use client';
import { ReactNode } from 'react';
import { Box } from '@mui/material';
import { Sidebar } from '@/components/ui';
export default function DashboardLayout({children}:{children:ReactNode}){return <Box sx={{display:'flex',minHeight:'100vh'}}><Sidebar/ ><Box component="main" sx={{flex:1,p:3}}>{children}</Box></Box>}
