'use client';
import { Box, Typography } from '@mui/material';
export default function DashboardExample(){return <Box><Typography variant="h4">Dashboard</Typography></Box>}
