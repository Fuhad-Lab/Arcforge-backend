'use client';
import { Box } from '@mui/material';
import { TextField, PasswordField, Checkbox, PrimaryButton } from '@/components/ui';
export default function CompleteForm(){return <Box component="form" sx={{display:'grid',gap:1}}><TextField label="Email"/><PasswordField/><Checkbox label="Remember me"/><PrimaryButton>Submit</PrimaryButton></Box>}
