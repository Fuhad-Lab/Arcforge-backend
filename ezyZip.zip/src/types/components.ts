export interface SelectOption<T=string>{label:string;value:T;disabled?:boolean;}
export interface PaginationProps{page:number;pageSize:number;total:number;}
