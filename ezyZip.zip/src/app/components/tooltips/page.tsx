'use client';
import { Box, Typography } from '@mui/material';
export default function TooltipsPage(){return <Box sx={{p:3}}><Typography variant="h4">Tooltips Components</Typography><Typography color="text.secondary">Use the reusable components from @/components/ui.</Typography></Box>}
