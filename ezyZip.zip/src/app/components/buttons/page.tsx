'use client';
import { Box, Typography, Paper } from '@mui/material';
import { PrimaryButton, SecondaryButton, IconButton, ButtonGroup } from '@/components/ui';
import { Save, Delete } from '@mui/icons-material';
export default function ButtonsPage(){return <Box sx={{p:3}}><Typography variant="h4" gutterBottom>Button Components</Typography><Paper sx={{p:3}}><Box sx={{display:'flex',gap:2,flexWrap:'wrap'}}><PrimaryButton>Submit</PrimaryButton><PrimaryButton icon={<Save/>}>Save Changes</PrimaryButton><PrimaryButton loading loadingText="Saving...">Loading</PrimaryButton><SecondaryButton>Cancel</SecondaryButton><IconButton tooltip="Delete"><Delete/></IconButton><ButtonGroup items={[{value:'day',label:'Day'},{value:'week',label:'Week'},{value:'month',label:'Month'}]}/></Box></Paper></Box>}
