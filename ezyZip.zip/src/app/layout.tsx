'use client';
import { ReactNode } from 'react';
import { ThemeProvider, CssBaseline } from '@mui/material';
import createTheme from '@/lib/theme/createTheme';
import './globals.css';
const theme=createTheme();
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body><ThemeProvider theme={theme}><CssBaseline/>{children}</ThemeProvider></body></html>}
