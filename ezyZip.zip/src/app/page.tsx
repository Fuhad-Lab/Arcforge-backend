'use client';
import { Box, Typography, Container } from '@mui/material';
import { PrimaryButton, SecondaryButton } from '@/components/ui';
export default function Home(){return <Container maxWidth="lg"><Box sx={{py:8}}><Typography variant="h2" gutterBottom>Vibe Workspace</Typography><Typography color="text.secondary" paragraph>Reusable Material UI component template.</Typography><Box sx={{display:'flex',gap:2}}><PrimaryButton>Get Started</PrimaryButton><SecondaryButton>Explore Components</SecondaryButton></Box></Box></Container>}
