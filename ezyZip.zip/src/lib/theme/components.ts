export const components = {} as const;
