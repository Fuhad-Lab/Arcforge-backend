export const palette = { primary:'#1976d2', secondary:'#dc004e', background:'#f5f5f5' } as const;
