import { createTheme as createMuiTheme, ThemeOptions } from '@mui/material/styles';
export const createTheme=(options:ThemeOptions={})=>createMuiTheme({
 palette:{mode:'light',primary:{main:'#1976d2',light:'#42a5f5',dark:'#1565c0',contrastText:'#fff'},secondary:{main:'#dc004e',light:'#ff5983',dark:'#c2185b',contrastText:'#fff'},error:{main:'#f44336',light:'#ff7961',dark:'#d32f2f'},warning:{main:'#ff9800',light:'#ffb74d',dark:'#f57c00'},info:{main:'#2196f3',light:'#64b5f6',dark:'#1976d2'},success:{main:'#4caf50',light:'#81c784',dark:'#388e3c'},background:{default:'#f5f5f5',paper:'#fff'},text:{primary:'rgba(0,0,0,.87)',secondary:'rgba(0,0,0,.6)',disabled:'rgba(0,0,0,.38)'}},
 typography:{fontFamily:'"Roboto","Helvetica","Arial",sans-serif',h1:{fontSize:'3rem',fontWeight:600,lineHeight:1.2},h2:{fontSize:'2.5rem',fontWeight:600,lineHeight:1.2},h3:{fontSize:'2rem',fontWeight:600,lineHeight:1.3},h4:{fontSize:'1.75rem',fontWeight:600,lineHeight:1.35},h5:{fontSize:'1.5rem',fontWeight:600,lineHeight:1.4},h6:{fontSize:'1.25rem',fontWeight:600,lineHeight:1.5},body1:{fontSize:'1rem',lineHeight:1.6},body2:{fontSize:'.875rem',lineHeight:1.5},caption:{fontSize:'.75rem',lineHeight:1.4},button:{textTransform:'none',fontWeight:500}},
 shape:{borderRadius:8},spacing:8,
 ...options
});
export default createTheme;
