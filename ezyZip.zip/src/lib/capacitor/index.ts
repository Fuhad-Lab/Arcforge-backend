export const isCapacitorAvailable=()=>typeof window!=='undefined'&&'Capacitor' in window;
