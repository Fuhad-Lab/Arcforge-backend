export const cn=(...values:Array<string|false|null|undefined>)=>values.filter(Boolean).join(' ');
export const clamp=(value:number,min:number,max:number)=>Math.min(Math.max(value,min),max);
