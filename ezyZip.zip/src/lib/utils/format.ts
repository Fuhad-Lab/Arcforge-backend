export const formatCurrency=(value:number,currency='USD',locale='en-US')=>new Intl.NumberFormat(locale,{style:'currency',currency}).format(value);
export const formatDate=(date:Date|string|number,locale='en-US')=>new Intl.DateTimeFormat(locale).format(new Date(date));
