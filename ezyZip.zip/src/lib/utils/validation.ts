export const isEmail=(value:string)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
export const isRequired=(value:unknown)=>value!==null&&value!==undefined&&String(value).trim().length>0;
